//
//  ViewController.swift
//  FacultyLocations
//
//  Created by Hein Thant on 17/8/2567 BE.
//

import UIKit
import MapKit

class ViewController: UIViewController, MKMapViewDelegate {

    @IBOutlet weak var mapView: MKMapView!
    var places: [Place] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        
        mapView.delegate = self  // Set the delegate to self
        loadPlaces()
        setupMap()
    }
    
    // Load JSON data
    func loadPlaces() {
        guard let url = Bundle.main.url(forResource: "places", withExtension: "json") else {
            print("JSON file not found")
            return
        }
        
        do {
            let data = try Data(contentsOf: url)
            if let jsonString = String(data: data, encoding: .utf8) {
                print("Raw JSON: \(jsonString)")
            }
            let placesData = try JSONDecoder().decode(PlacesData.self, from: data)
            places = placesData.places
        } catch {
            print("Error decoding JSON: \(error)")
        }
    }

    
    // Set up the map with annotations
    func setupMap() {
        // Set the initial location to ABAC Center
        let initialLocation = CLLocationCoordinate2D(latitude: 13.612320, longitude: 100.836808)
        let region = MKCoordinateRegion(center: initialLocation, latitudinalMeters: 1000, longitudinalMeters: 1000)
        mapView.setRegion(region, animated: true)
        
        // Add annotations for the places
        for place in places {
            let annotation = MKPointAnnotation()
            annotation.title = place.facultyName
            annotation.subtitle = place.abbreviation
            annotation.coordinate = place.coordinate
            mapView.addAnnotation(annotation)
        }
    }
    
    // MKMapViewDelegate method to show callouts with detail buttons
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        let identifier = "PlacePin"
        
        var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier) as? MKMarkerAnnotationView
        if annotationView == nil {
            annotationView = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            annotationView?.canShowCallout = true
            annotationView?.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
        } else {
            annotationView?.annotation = annotation
        }
        
        return annotationView
    }
    
    // Show alert when callout detail button is clicked
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        if let annotationTitle = view.annotation?.title! {
            let alert = UIAlertController(title: annotationTitle, message: "You tapped on \(annotationTitle)", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
        }
    }
}
