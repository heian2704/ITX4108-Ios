//
//  Place.swift
//  FacultyLocations
//
//  Created by Hein Thant on 17/8/2567 BE.
//

import Foundation
import CoreLocation

struct Place: Codable {
    let facultyName: String
    let abbreviation: String
    let imageLogoName: String
    let locationLat: Double
    let locationLong: Double
    
    enum CodingKeys: String, CodingKey {
        case facultyName = "FacultyName"
        case abbreviation = "Abbreviation"
        case imageLogoName = "ImageLogoName"
        case locationLat = "LocationLat"
        case locationLong = "LocationLong"
    }
    
    var coordinate: CLLocationCoordinate2D {
        return CLLocationCoordinate2D(latitude: locationLat, longitude: locationLong)
    }
}

struct PlacesData: Codable {
    let places: [Place]
    
    enum CodingKeys: String, CodingKey {
        case places = "Places"
    }
}
