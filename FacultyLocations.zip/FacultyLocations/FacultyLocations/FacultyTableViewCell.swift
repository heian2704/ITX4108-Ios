//
//  FacultyTableViewCell.swift
//  FacultyLocations
//
//  Created by Hein Thant on 17/8/2567 BE.
//

import UIKit

class FacultyTableViewCell: UITableViewCell {
    @IBOutlet weak var logoImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var distanceLabel: UILabel!
}

