//
//  ListViewController.swift
//  FacultyLocations
//
//  Created by Hein Thant on 17/8/2567 BE.
//

import UIKit
import CoreLocation

class ListViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, CLLocationManagerDelegate {

    @IBOutlet weak var tableView: UITableView!
    
    var places: [Place] = []
    var currentLocation: CLLocation?
    let locationManager = CLLocationManager()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.dataSource = self
        tableView.delegate = self
        
        setupLocationManager()
        loadPlaces()
    }

    private func setupLocationManager() {
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
    }

    private func loadPlaces() {
        if let url = Bundle.main.url(forResource: "places", withExtension: "json") {
            do {
                let data = try Data(contentsOf: url)
                let placesData = try JSONDecoder().decode(PlacesData.self, from: data)
                places = placesData.places
            } catch {
                print("Error loading or decoding JSON data: \(error)")
            }
        }
    }

    // MARK: - CLLocationManagerDelegate Methods

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.last {
            currentLocation = location
            tableView.reloadData() // Refresh the table view with new location data
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Failed to find user's location: \(error.localizedDescription)")
    }

    // MARK: - UITableViewDataSource Methods

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return places.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "FacultyCell", for: indexPath) as? FacultyTableViewCell else {
            return UITableViewCell()
        }
        
        let place = places[indexPath.row]
        cell.logoImageView.image = UIImage(named: place.imageLogoName)
        cell.nameLabel.text = place.facultyName
        
        if let currentLocation = currentLocation {
            let distance = calculateDistance(from: currentLocation.coordinate, to: place.coordinate)
            cell.distanceLabel.text = String(format: "Distance: %.2f km", distance)
        } else {
            cell.distanceLabel.text = "Distance: N/A"
        }
        
        return cell
    }

    private func calculateDistance(from coordinate1: CLLocationCoordinate2D, to coordinate2: CLLocationCoordinate2D) -> Double {
        let lat1 = coordinate1.latitude.toRadians()
        let lon1 = coordinate1.longitude.toRadians()
        let lat2 = coordinate2.latitude.toRadians()
        let lon2 = coordinate2.longitude.toRadians()
        
        let dLat = lat2 - lat1
        let dLon = lon2 - lon1
        
        let a = sin(dLat / 2) * sin(dLat / 2) + cos(lat1) * cos(lat2) * sin(dLon / 2) * sin(dLon / 2)
        let c = 2 * atan2(sqrt(a), sqrt(1 - a))
        
        let R: Double = 6371 // Earth’s radius in kilometers
        return R * c
    }
}

extension CLLocationDegrees {
    func toRadians() -> Double {
        return self * .pi / 180
    }
}
