// MovieCollectionViewCell.swift
import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var posterImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var releaseDateLabel: UILabel!
    @IBOutlet weak var genreLabel: UILabel!

    // Configure the cell with the movie data
    func configure(with movie: Movie) {
        titleLabel.text = movie.title_en
        releaseDateLabel.text = "Release Date: \(movie.release_date)"
        genreLabel.text = "Genre: \(movie.genre)"
        
        // Load the image from the URL using URLSession
        if let url = URL(string: movie.poster_url) {
            URLSession.shared.dataTask(with: url) { data, response, error in
                guard let data = data, error == nil else { return }
                DispatchQueue.main.async {
                    self.posterImageView.image = UIImage(data: data)
                }
            }.resume()
        }
    }
}
