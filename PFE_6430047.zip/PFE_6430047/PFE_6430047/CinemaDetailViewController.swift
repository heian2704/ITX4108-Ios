import UIKit
import WebKit

class CinemaDetailViewController: UIViewController {

    @IBOutlet weak var webView: WKWebView!

    var cinemaName: String?
    var zoneName: String?
    var cinemaTel: String?
    var cinemaContent: String?
    var officeHour: String?
    var brandName: String?

    override func viewDidLoad() {
        super.viewDidLoad()
        loadCinemaDetails()
    }

    // Load cinema details into the web view
    private func loadCinemaDetails() {
        // Ensure brandName is not nil
        guard let brandName = brandName else {
            print("Brand name is nil.")
            return
        }

        // Get the brand image
        guard let brandImage = getBrandImage(brand: brandName) else {
            print("Brand image not found.")
            return
        }

        // Convert UIImage to PNG data
        guard let imageData = brandImage.pngData() else {
            print("Failed to convert image to PNG data.")
            return
        }

        // Convert PNG data to Base64 string
        let base64Image = imageData.base64EncodedString()

        // Create HTML string
        let htmlString = """
        <html>
        <head>
            <style>
                body { font-family: -apple-system; font-size: 16px; padding: 10px; }
                h1 { color: #333; }
                h2 { color: #555; }
                p { color: #666; }
                img { max-width: 100%; height: auto; }
            </style>
        </head>
        <body>
            <h1>\(cinemaName ?? "Cinema Name")</h1>
            <h2>Zone: \(zoneName ?? "Zone Name")</h2>
            <p><strong>Telephone:</strong> \(cinemaTel ?? "N/A")</p>
            <p><strong>Brand:</strong> \(brandName ?? "N/A")</p>
            <p><strong>Office Hour:</strong> \(officeHour ?? "N/A")</p>
            <h2>Brand Image</h2>
            <img src="data:image/png;base64,\(base64Image)" alt="Brand Image">
            <h2>Description</h2>
            <p>\(cinemaContent ?? "No content available.")</p>
        </body>
        </html>
        """

        webView.loadHTMLString(htmlString, baseURL: nil)
    }
    
    // Function to get the brand image based on brand name
    private func getBrandImage(brand: String) -> UIImage? {
        switch brand {
        case "Paragon Cineplex":
            return UIImage(named: "paragon") // Ensure you have "paragon" image in your asset catalog
        case "Icon Cineconic":
            return UIImage(named: "icon") // Ensure you have "icon" image in your asset catalog
        case "Quartire Cineart":
            return UIImage(named: "emq") // Ensure you have "emq" image in your asset catalog
        case "IMAX Laser":
            return UIImage(named: "imax") // Ensure you have "imax" image in your asset catalog
        default:
            return UIImage(named: "major") // Ensure you have "major" image in your asset catalog
        }
    }
}
