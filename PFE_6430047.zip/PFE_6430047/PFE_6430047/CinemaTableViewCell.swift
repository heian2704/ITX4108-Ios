import UIKit

class CinemaTableViewCell: UITableViewCell {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var zoneBrandLabel: UILabel!
    @IBOutlet weak var brandImageView: UIImageView!
    @IBOutlet weak var favoriteButton: UIButton!

    override func awakeFromNib() {
        super.awakeFromNib()
    }

    // Function to configure the cell with cinema data
    func configure(with cinema: Cinema, isFavorite: Bool) {
        nameLabel.text = cinema.cinemaNameEn
        zoneBrandLabel.text = "\(cinema.zoneNameEn) - \(cinema.brandNameEn)"
        brandImageView.image = getBrandImage(brand: cinema.brandNameEn)

        // Update the favorite button's appearance
        let buttonImage = isFavorite ? UIImage(systemName: "star.fill") : UIImage(systemName: "star")
        favoriteButton.setImage(buttonImage, for: .normal)
    }

    // Function to get the brand image based on brand name
    private func getBrandImage(brand: String) -> UIImage? {
        switch brand {
        case "Paragon Cineplex":
            return UIImage(named: "paragon")
        case "Icon Cineconic":
            return UIImage(named: "icon")
        case "Quartire Cineart":
            return UIImage(named: "emq")
        case "IMAX Laser":
            return UIImage(named: "imax")
        default:
            return UIImage(named: "major")
        }
    }
}
