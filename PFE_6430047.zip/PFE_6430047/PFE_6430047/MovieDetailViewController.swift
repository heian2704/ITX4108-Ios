import UIKit
import AVKit

class MovieDetailViewController: UIViewController {

    @IBOutlet weak var posterImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var releaseDateLabel: UILabel!
    @IBOutlet weak var genreLabel: UILabel!
    @IBOutlet weak var durationLabel: UILabel!
    @IBOutlet weak var synopsisTextView: UILabel!

    var movie: Movie? // Movie object passed from the previous view controller

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }

    private func setupUI() {
        guard let movie = movie else { return }
        if let url = URL(string: movie.poster_url) {
            posterImageView.load(url: url) // Load poster image using the extension
        }
        titleLabel.text = movie.title_en
        releaseDateLabel.text = "Release Date: \(movie.release_date)"
        genreLabel.text = "Genre: \(movie.genre)"
        durationLabel.text = "Duration: \(movie.duration) min"
        synopsisTextView.text = movie.synopsis_en
    }

    @IBAction func playTrailerButtonTapped(_ sender: UIButton) {
        guard let trailerURL = movie?.tr_mp4 else { return }
        playTrailer(url: trailerURL)
    }

    private func playTrailer(url: String) {
        guard let videoURL = URL(string: url) else { return }
        let player = AVPlayer(url: videoURL)
        let playerViewController = AVPlayerViewController()
        playerViewController.player = player

        present(playerViewController, animated: true) {
            playerViewController.player?.play() // Start playing the video
        }
    }
}
