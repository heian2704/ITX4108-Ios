import UIKit
import Alamofire

class CinemaViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var tableView: UITableView!

    var cinemas: [Cinema] = []
    var favoriteCinemas: Set<String> = [] // To keep track of favorite cinemas
    var isFavoritesOnly = false

    override func viewDidLoad() {
        super.viewDidLoad()

        tableView.dataSource = self
        tableView.delegate = self
        
        // Fetch cinemas data
        fetchCinemas()
    }

    // Fetch cinemas from the API
    func fetchCinemas() {
        let url = "https://www.majorcineplex.com/apis/get_cinema"
        
        // Request the cinema data using Alamofire
        AF.request(url)
            .validate()
            .responseDecodable(of: CinemaResponse.self) { response in
                switch response.result {
                case .success(let cinemaResponse):
                    // Successfully decoded response
                    self.cinemas = cinemaResponse.cinemas
                    
                    // Reload the table view on the main thread
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                    }
                case .failure(let error):
                    print("Error fetching cinemas: \(error)")
                }
            }
    }

    // MARK: - UITableViewDataSource

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return isFavoritesOnly ? favoriteCinemas.count : cinemas.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "CinemaCell", for: indexPath) as? CinemaTableViewCell else {
            return UITableViewCell()
        }

        let cinema: Cinema
        if isFavoritesOnly {
            // Filter cinemas based on favorites
            let favoriteCinemasList = cinemas.filter { favoriteCinemas.contains($0.cinemaNameEn) }
            cinema = favoriteCinemasList[indexPath.row]
        } else {
            cinema = cinemas[indexPath.row]
        }

        // Configure the cell
        cell.configure(with: cinema, isFavorite: favoriteCinemas.contains(cinema.cinemaNameEn))
        
        // Handle favorite button action
        cell.favoriteButton.tag = indexPath.row
        cell.favoriteButton.addTarget(self, action: #selector(starButtonTapped(_:)), for: .touchUpInside)

        return cell
    }

    // MARK: - UITableViewDelegate

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        // Prepare to show cinema details
        let cinema: Cinema
        if isFavoritesOnly {
            let favoriteCinemasList = cinemas.filter { favoriteCinemas.contains($0.cinemaNameEn) }
            cinema = favoriteCinemasList[indexPath.row]
        } else {
            cinema = cinemas[indexPath.row]
        }
        
        // Show CinemaDetailViewController
        let detailVC = storyboard?.instantiateViewController(withIdentifier: "CinemaDetailViewController") as! CinemaDetailViewController
        
        // Pass data to the detail view controller
        detailVC.cinemaName = cinema.cinemaNameEn
        detailVC.zoneName = cinema.zoneNameEn
        detailVC.cinemaTel = cinema.cinemaTel
        detailVC.cinemaContent = cinema.cinemaContentMain
        detailVC.officeHour = cinema.cinemaOfficeHourEn
        detailVC.brandName = cinema.brandNameEn
        
        // Present the detail view controller as a page sheet
        detailVC.modalPresentationStyle = .pageSheet
        present(detailVC, animated: true, completion: nil)
    }

    // MARK: - Favorite Button Action

    @objc func starButtonTapped(_ sender: UIButton) {
        let cinema: Cinema
        if isFavoritesOnly {
            // Get the favorite cinema
            let favoriteCinemasList = cinemas.filter { favoriteCinemas.contains($0.cinemaNameEn) }
            cinema = favoriteCinemasList[sender.tag]
        } else {
            cinema = cinemas[sender.tag]
        }

        // Toggle favorite status
        if favoriteCinemas.contains(cinema.cinemaNameEn) {
            favoriteCinemas.remove(cinema.cinemaNameEn)
        } else {
            favoriteCinemas.insert(cinema.cinemaNameEn)
        }
        
        // Reload the relevant row
        tableView.reloadRows(at: [IndexPath(row: sender.tag, section: 0)], with: .none)
    }

    // Action for "All Cinemas" button
    @IBAction func allCinemasTapped(_ sender: UIButton) {
        isFavoritesOnly = false
        tableView.reloadData()
    }

    // Action for "Favorites" button
    @IBAction func favoritesTapped(_ sender: UIButton) {
        isFavoritesOnly = true
        tableView.reloadData()
    }
}
