import UIKit
import Alamofire

class MovieViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    @IBOutlet weak var collectionView: UICollectionView!
    var movies: [Movie] = []
    var nowShowing: Bool = true // Default to Now Showing

    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionView.delegate = self
        collectionView.dataSource = self
        
        // Fetch Now Showing movies by default
        fetchMovies()
    }

    @IBAction func nowShowingButtonTapped(_ sender: UIButton) {
        nowShowing = true
        fetchMovies()
    }

    @IBAction func upcomingButtonTapped(_ sender: UIButton) {
        nowShowing = false
        fetchMovies()
    }

    func fetchMovies() {
        let url = "https://www.majorcineplex.com/apis/get_movie_available"

        AF.request(url)
            .validate()
            .responseDecodable(of: MovieResponse.self) { response in
                switch response.result {
                case .success(let movieResponse):
                    if self.nowShowing {
                        self.movies = movieResponse.movies.filter { $0.now_showing == "1" }
                    } else {
                        self.movies = movieResponse.movies.filter {
                            $0.now_showing == nil || $0.now_showing?.isEmpty == true || $0.now_showing == "0"
                        }
                    }

                    DispatchQueue.main.async {
                        self.collectionView.reloadData()
                    }

                case .failure(let error):
                    print("Error fetching movies: \(error)")
                }
            }
    }

    // MARK: - UICollectionViewDataSource

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return movies.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MovieCell", for: indexPath) as! MovieCollectionViewCell
        let movie = movies[indexPath.item]
        
        cell.configure(with: movie)
        return cell
    }

    // MARK: - UICollectionViewDelegate

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let selectedMovie = movies[indexPath.item]
        presentMovieDetail(movie: selectedMovie) // Present the detail view controller
    }

    // Present the detail view controller
    private func presentMovieDetail(movie: Movie) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil) // Adjust if your storyboard has a different name
        if let detailVC = storyboard.instantiateViewController(withIdentifier: "MovieDetailViewController") as? MovieDetailViewController {
            detailVC.movie = movie // Pass the selected movie to the detail view
            detailVC.modalPresentationStyle = .pageSheet
            self.present(detailVC, animated: true, completion: nil) // Present the detail view controller
        }
    }

    // MARK: - UICollectionViewDelegateFlowLayout

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: view.frame.width / 2 - 10, height: 400)
    }
}
