import Foundation

struct MovieResponse: Decodable {
    let movies: [Movie]
}

struct Movie: Decodable {
    let id: Int
    let poster_url: String
    let title_en: String
    let release_date: String
    let genre: String
    let now_showing: String?// Keep this as String
    let rating: String
    let duration: Int
    let director: String
    let actor: String
    let synopsis_en: String
    let tr_mp4: String 
}
