import Foundation

struct Cinema: Codable {
    let cinemaNameEn: String
    let zoneNameEn: String
    let brandNameEn: String
    let cinemaTel: String?
    let cinemaContentMain: String?
    let cinemaOfficeHourEn: String?

    enum CodingKeys: String, CodingKey {
        case cinemaNameEn = "cinema_name_en"
        case zoneNameEn = "zone_name_en"
        case brandNameEn = "brand_name_en"
        case cinemaTel = "cinema_tel"
        case cinemaContentMain = "cinema_content_main"
        case cinemaOfficeHourEn = "cinema_office_hour_en"
    }
}

struct CinemaResponse: Codable {
    let cinemas: [Cinema]
}
