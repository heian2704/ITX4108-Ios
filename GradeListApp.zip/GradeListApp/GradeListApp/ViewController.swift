//
//  ViewController.swift
//  GradeListApp
//
//  Created by Hein Thant on 16/8/2567 BE.
//

import UIKit
import Alamofire

class ViewController: UIViewController, UITableViewDataSource  {
    
    @IBOutlet weak var tableView: UITableView!

    var grades = [Grade]()

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        fetchStudentData()
    }

    func fetchStudentData() {
        let url = "https://dl.dropboxusercontent.com/s/nsicnigp0xc8dxz/grades.json"
            AF.request(url).responseDecodable(of: Student.self) { response in
                switch response.result {
                case .success(let student):
                    self.grades = student.grades
                    self.tableView.reloadData()
                case .failure(let error):
                    print("Error fetching grades: \(error)")
            }
        }
    }

        // UITableViewDataSource Methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return grades.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "GradeCell", for: indexPath) as! GradeCell
            let grade = grades[indexPath.row]

            cell.codeLabel.text = grade.code
            cell.nameLabel.text = grade.name
            cell.creditLabel.text = "\(grade.credit)"
            cell.gradeLabel.text = grade.grade

            return cell
        }

}
