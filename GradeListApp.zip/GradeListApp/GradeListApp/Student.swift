//
//  Student.swift
//  GradeListApp
//
//  Created by Hein Thant on 16/8/2567 BE.
//

import Foundation

// Define the Grade structure
struct Grade: Decodable {
    var code: String
    var credit: Double
    var name: String
    var grade: String
}

// Define the Student structure
struct Student: Decodable {
    var name: String
    var grades: [Grade]
}
