//
//  ViewController.swift
//  Assignment6
//
//  Created by Hein Thant on 16/7/2567 BE.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

