//
//  ItemDetailViewController.swift
//  Assignment6
//
//  Created by Hein Thant on 9/7/2567 BE.
//

import UIKit

class ItemDetailViewController: UIViewController {
    
    @IBOutlet weak var appNameLabel: UILabel!
    @IBOutlet weak var appIconImageView: UIImageView!
    @IBOutlet weak var shortDescriptionLabel: UILabel!
    @IBOutlet weak var ratingLabel: UILabel!
    @IBOutlet weak var ageLabel: UILabel!
    @IBOutlet weak var topChartPositionLabel: UILabel!
    @IBOutlet weak var detailedDescriptionLabel: UILabel!
    @IBOutlet weak var imageView1: UIImageView!
    @IBOutlet weak var imageView2: UIImageView!
    @IBOutlet weak var imageView3: UIImageView!

    var app: AppInfo?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        appIconImageView.clipsToBounds = true
        appIconImageView.layer.cornerRadius = 20
        
        if let app {
            self.title = "\(app.appName)"
            appIconImageView.image = UIImage(named: app.appIcon)
            appNameLabel.text = app.appName
            shortDescriptionLabel.text = app.shortDescription
            ratingLabel.text = "\(app.rating)"
            ageLabel.text = "\(app.age)"
            topChartPositionLabel.text = "\(app.topChartPosition)"
            detailedDescriptionLabel.text = app.detailedDescription
            imageView1.image = UIImage(named: app.screenshotGallery[0])
            imageView2.image = UIImage(named: app.screenshotGallery[1])
            imageView3.image = UIImage(named: app.screenshotGallery[2])
        }

    }
    


}
