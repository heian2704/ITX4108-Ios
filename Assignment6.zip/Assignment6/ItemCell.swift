//
//  ItemCell.swift
//  Assignment6
//
//  Created by Hein Thant on 10/7/2567 BE.
//

import UIKit

class ItemCell: UITableViewCell {
    
    @IBOutlet weak var productImage: UIImageView!
    @IBOutlet weak var productNameLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        productImage.contentMode = .scaleAspectFit
        productImage.clipsToBounds = true
        productImage.layer.cornerRadius = 12

    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

    func set(topTenApps: AppInfo ) {
        productNameLabel.text = topTenApps.appName
        descriptionLabel.text = topTenApps.shortDescription
        productImage.image = UIImage(named: topTenApps.appIcon)
    }

}
