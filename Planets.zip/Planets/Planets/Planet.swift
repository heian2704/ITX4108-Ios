//
//  Planet.swift
//  Planets
//
//  Created by Hein Thant on 24/8/2567 BE.
//

import Foundation

struct Planet {
    let imageName: String
    let name: String
}
