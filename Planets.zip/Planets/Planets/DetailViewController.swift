//
//  DetailViewController.swift
//  Planets
//
//  Created by Hein Thant on 24/8/2567 BE.
//

import UIKit

class DetailViewController: UIViewController {
    
    @IBOutlet weak var planetImageView: UIImageView!
    @IBOutlet weak var planetNameLabel: UILabel!
    @IBOutlet weak var backBtn : UIButton!
    
    var planet: Planet?  // This will hold the selected planet
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Configure the view with the selected planet data
        if let planet = planet {
            planetImageView.image = UIImage(named: planet.imageName)
            planetNameLabel.text = planet.name
        }
    }
    @IBAction func backButtonTapped(_ sender: UIButton) {
        // Dismiss the view controller
        self.dismiss(animated: true, completion: nil)
    }
}
