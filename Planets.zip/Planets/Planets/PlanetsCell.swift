//
//  PlanetsCell.swift
//  Planets
//
//  Created by Hein Thant on 24/8/2567 BE.
//

import UIKit

class PlanetsCell: UICollectionViewCell {
    @IBOutlet weak var planetsImage: UIImageView!
    @IBOutlet weak var planetsLabel: UILabel!
    
    func configure(planet: Planet){
        planetsImage.image = UIImage(named: planet.imageName)
        planetsLabel.text = planet.name
    }

}
