import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var collectionView: UICollectionView!

    let planets: [Planet] = [
        Planet(imageName: "mercury", name: "Mercury"),
        Planet(imageName: "venus", name: "Venus"),
        Planet(imageName: "earth", name: "Earth"),
        Planet(imageName: "mars", name: "Mars"),
        Planet(imageName: "jupiter", name: "Jupiter"),
        Planet(imageName: "saturn", name: "Saturn"),
        Planet(imageName: "uranus", name: "Uranus"),
        Planet(imageName: "neptune", name: "Neptune")
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.delegate = self
        collectionView.dataSource = self
    }
}

extension ViewController: UICollectionViewDataSource, UICollectionViewDelegate{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return planets.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PlanetsCell", for: indexPath) as? PlanetsCell else {
            return UICollectionViewCell()
        }
        let planet = planets[indexPath.row]
        cell.configure(planet: planet)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
            if let detailVC = storyboard.instantiateViewController(withIdentifier: "DetailViewController") as? DetailViewController {
                detailVC.planet = planets[indexPath.row]
                detailVC.modalPresentationStyle = .fullScreen // Or .pageSheet, .formSheet, etc.
                self.present(detailVC, animated: true, completion: nil)
        }
    }
}
